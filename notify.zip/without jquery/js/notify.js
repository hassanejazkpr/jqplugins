$(document).ready(function(){
    // Setting Notification Default Id
    window.notif_id = 1;
});
(function ( $ ) {
    $.fn.notify = function( options ) {
        if($(this).attr('id') == 'notify'){
            // This is the easiest way to have default options.
            var def = $.extend({
                // These are the defaults.
                title: "Notification",
                text: "A dummy notification...",
                theme: 'light',
                animation: 'bounceIn',
            }, options );
            var theme = '';
            if(def.theme == 'success'){
                theme = 'notify-success';
            }else if(def.theme == 'info'){
                theme = 'notify-info';
            }else if(def.theme == 'warning'){
                theme = 'notify-warning';
            }else if(def.theme == 'danger'){
                theme = 'notify-danger';
            }else if(def.theme == 'dark'){
                theme = 'dark';
            }else{
                theme = 'light';
            }
            var html = '<div id="notif_no_'+notif_id+'" onclick="hide_notif('+notif_id+');" class="' +theme+ ' notify_noti animated '+def.animation+'">'+
            '<div class="notify_noti_header">'+
            '<h4>'+def.title+'</h4>'+
            '</div>'+
            '<div class="notify_noti_body">'+
            '<p>'+def.text+'</p>'+
            '</div>'+
            '</div>';
            $(this).prepend(html);
             var n_i = notif_id;
             setTimeout(function(){
                 hide_notif(n_i, def.animation);
             },3000);
            notif_id++;
        }else{
            alert('The Selected Div Must Have (id="notify")!');
        }
    };
}( jQuery ));

function hide_notif(id, animation){
    $('#notif_no_'+id).removeClass(animation).addClass('bounceOut');
    setTimeout(function(){
        $('#notif_no_'+id).remove();
    },700);
}